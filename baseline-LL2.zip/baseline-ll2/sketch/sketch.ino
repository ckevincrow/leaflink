/*
 * LEAFLINK HARDWARE ACQUISITION FIRMWARE
 * VERSION: 1.6.103 
 */
//Prints errors for debugging
#define ENABLE_DEBUG 1

// --- HARDWARE CONFIGURATION ---
#define CFG_ENABLE_OPTICAL    0
#define CFG_ENABLE_ANEMOMETER 0
#define CFG_ENABLE_PROXIMITY  0
#define CFG_ENABLE_TELEMETRY  0
#define CFG_MAX_SATS          12

#include <Wire.h>
#include <Arduino_RouterBridge.h>
#include <Adafruit_SHT31.h>
#include <Adafruit_BMP3XX.h>
#include <Adafruit_INA260.h>
#include <ArduinoJson.h>

#define FW_VERSION "1.6.103"

#if CFG_ENABLE_TELEMETRY
  const uint8_t PIN_ALERT = 9;
  #if defined(HAVE_HWSERIAL1)
    #define hc12 Serial1
  #else
    #define hc12 Serial 
  #endif
#endif

#if CFG_ENABLE_OPTICAL
  const uint8_t PIN_C12880MA_ST    = 7; 
  const uint8_t PIN_C12880MA_CLK   = 8;
  const uint8_t PIN_C12880MA_VIDEO = A2;
  const int N_PIXELS = 288;
  const int INTEG_CLKS = 20;
  uint16_t spec[N_PIXELS];
  uint16_t darkSpec[N_PIXELS] = {0};
  uint16_t currentSpec[N_PIXELS];
  bool darkCalDone = false;
  String cachedSpecStr = "[]";
#endif

#if CFG_ENABLE_ANEMOMETER
  const uint8_t PIN_ANEMOMETER = A0;
#endif

#if CFG_ENABLE_PROXIMITY
  const uint8_t PIN_FRONT_TRIG = 2;
  const uint8_t PIN_FRONT_ECHO = 3;
  const uint8_t PIN_REAR_TRIG  = 4;
  const uint8_t PIN_REAR_ECHO  = 6;
  char move_dir = 'F';
  bool is_stopped = false;
  uint32_t stop_start_time = 0;
  long last_front_dist = 0;
  long last_rear_dist = 0;
#endif

const uint8_t I2C_GNSS = 0x42;
Adafruit_SHT31 sht31;
Adafruit_BMP3XX bmp;

Adafruit_INA260& getINA260() {
  static Adafruit_INA260 local_ina;
  return local_ina;
}

bool has_GNSS = false, has_SHT31 = false, has_BMP388 = false, has_INA260 = false;
bool audit_performed = false;
uint32_t local_seq = 0;

int32_t c_lat = 0, c_lon = 0, c_alt = 0;
uint32_t c_hacc = 0, c_vacc = 0;
uint8_t c_siv = 0;
uint16_t c_agc0 = 0, c_agc1 = 0; 
uint8_t c_jam0 = 0, c_jam1 = 0;

char c_svs[(CFG_MAX_SATS * 2) + 1] = "";
char c_cno[(CFG_MAX_SATS * 2) + 1] = "";
char c_gns[(CFG_MAX_SATS * 2) + 1] = "";
char c_ts[25] = "";

int32_t c_temp = 0, c_hum = 0, c_pres = 0, c_wind = 0;
int32_t c_volt = 0, c_curr = 0, c_pwr = 0;

StaticJsonDocument<3072> doc;
char jsonBuf[3072];

void logDebug(const __FlashStringHelper* m) {
  #if ENABLE_DEBUG
  Bridge.notify(F("debug"), String(m));
  Bridge.update();
  delay(100);
  #endif
}

#if CFG_ENABLE_OPTICAL
void clk() { digitalWrite(PIN_C12880MA_CLK, HIGH); delayMicroseconds(1); digitalWrite(PIN_C12880MA_CLK, LOW); delayMicroseconds(1); }

void getSpectrum(uint16_t *data) {
  digitalWrite(PIN_C12880MA_ST, HIGH);
  for (int i = 0; i < INTEG_CLKS; i++) clk();
  digitalWrite(PIN_C12880MA_ST, LOW);
  for (int i = 0; i < 16; i++) clk();
  for (int i = 0; i < N_PIXELS; i++) { clk(); data[i] = analogRead(PIN_C12880MA_VIDEO); }
}

void doDarkCalibration() {
  const int N = 50;
  uint32_t accum[N_PIXELS] = {0};
  for (int n = 0; n < N; n++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) accum[i] += spec[i];
    delay(10);
  }
  for (int i = 0; i < N_PIXELS; i++) darkSpec[i] = accum[i] / N;
  darkCalDone = true;
}

void pollOptical() {
  uint32_t accum[N_PIXELS] = {0};
  int samples = 40;
  for (int s = 0; s < samples; s++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) {
      int32_t v = spec[i] - (darkCalDone ? darkSpec[i] : 0);
      accum[i] += (v < 0) ? 0 : v;
    }
    if (has_GNSS) pollUBX();
    delay(5);
  }
  cachedSpecStr = "[";
  for (int i = 0; i < N_PIXELS; i++) {
    currentSpec[i] = accum[i] / samples;
    cachedSpecStr += String(currentSpec[i]);
    if (i < N_PIXELS - 1) cachedSpecStr += ",";
  }
  cachedSpecStr += "]";
}
#endif

#if CFG_ENABLE_PROXIMITY
long readDist(uint8_t t, uint8_t e) {
  digitalWrite(t, LOW); delayMicroseconds(2); digitalWrite(t, HIGH); delayMicroseconds(10); digitalWrite(t, LOW);
  long d = pulseIn(e, HIGH, 30000);
  return (d == 0) ? 999 : d * 0.034 / 2;
}

void pollProx() {
  static uint32_t lp = 0; if (millis() - lp < 100) return; lp = millis();
  last_front_dist = readDist(PIN_FRONT_TRIG, PIN_FRONT_ECHO);
  last_rear_dist = readDist(PIN_REAR_TRIG, PIN_REAR_ECHO);
  
  if (is_stopped) {
    #if CFG_ENABLE_TELEMETRY
    hc12.write('S');
    #endif
    if (millis() - stop_start_time >= 4000) {
      if (move_dir == 'F') { if (last_front_dist <= 30) move_dir = 'B'; }
      else { if (last_rear_dist <= 30) move_dir = 'F'; }
      is_stopped = false;
    }
  } else {
    long d = (move_dir == 'F') ? last_front_dist : last_rear_dist;
    if (d <= 30) { is_stopped = true; stop_start_time = millis(); }
    #if CFG_ENABLE_TELEMETRY
    hc12.write(is_stopped ? 'S' : move_dir);
    #endif
  }
}
#endif

void sendUBX(uint8_t cls, uint8_t id, uint8_t* pay, uint16_t len) {
  uint8_t h[] = {0xB5, 0x62, cls, id, (uint8_t)(len & 0xFF), (uint8_t)(len >> 8)};
  uint8_t ckA = 0, ckB = 0;
  for (uint8_t i = 2; i < 6; i++) { ckA += h[i]; ckB += ckA; }
  for (uint16_t i = 0; i < len; i++) { ckA += pay[i]; ckB += ckA; }
  Wire1.beginTransmission(I2C_GNSS);
  Wire1.write(h, 6);
  if (len > 0) Wire1.write(pay, len);
  Wire1.write(ckA); Wire1.write(ckB);
  Wire1.endTransmission();
}

void processUBX(uint8_t cls, uint8_t id, uint16_t len, uint8_t* buf) {
  if (cls == 0x01 && id == 0x07 && len >= 92) {
    if (buf[20] >= 3) {
      c_siv = buf[23];
      c_lon = ((int32_t)buf[27] << 24) | ((int32_t)buf[26] << 16) | ((int32_t)buf[25] << 8) | buf[24];
      c_lat = ((int32_t)buf[31] << 24) | ((int32_t)buf[30] << 16) | ((int32_t)buf[29] << 8) | buf[28];
      c_alt = ((int32_t)buf[39] << 24) | ((int32_t)buf[38] << 16) | ((int32_t)buf[37] << 8) | buf[36];
      c_hacc = ((uint32_t)buf[43]<<24) | ((uint32_t)buf[42]<<16) | ((uint32_t)buf[41]<<8) | buf[40];
      c_vacc = ((uint32_t)buf[47]<<24) | ((uint32_t)buf[46]<<16) | ((uint32_t)buf[45]<<8) | buf[44];
      snprintf(c_ts, 25, "%04d-%02d-%02dT%02d:%02d:%02dZ", buf[4]|(buf[5]<<8), buf[6], buf[7], buf[8], buf[9], buf[10]);
    }
  } else if (cls == 0x01 && id == 0x35 && len >= 8) {
    uint8_t num = buf[5], stored = 0; c_svs[0] = c_cno[0] = c_gns[0] = '\0';
    for (uint8_t j = 0; j < num && stored < CFG_MAX_SATS; j++) {
      uint16_t o = 8 + (j * 12); if (o + 3 > len) break;
      if (buf[o] <= 1) { 
        sprintf(c_svs + (stored * 2), "%02X", buf[o + 1]);
        sprintf(c_cno + (stored * 2), "%02X", buf[o + 2]);
        sprintf(c_gns + (stored * 2), "%02X", buf[o]);
        stored++;
      }
    }
  } else if (cls == 0x0A && id == 0x38 && len >= 4) {
    uint8_t n = buf[1];
    if (n >= 1) { c_agc0 = buf[10] | ((uint16_t)buf[11]<<8); c_jam0 = buf[12]; }
    if (n >= 2) { c_agc1 = buf[20] | ((uint16_t)buf[21]<<8); c_jam1 = buf[22]; }
  }
}

void pollUBX() {
  static uint8_t ubx_state = 0, ubx_cls = 0, ubx_id = 0;
  static uint16_t ubx_len = 0, ubx_idx = 0;
  static uint8_t ubx_ckA = 0, ubx_ckB = 0;
  static uint8_t ubx_buf[1024];

  Wire1.beginTransmission(I2C_GNSS);
  Wire1.write(0xFD);
  if (Wire1.endTransmission(false) != 0) return;
  Wire1.requestFrom(I2C_GNSS, (uint8_t)2);
  if (Wire1.available() < 2) return;
  uint16_t avail = (Wire1.read() << 8) | Wire1.read();
  
  if (avail > 2048) avail = 2048;

  while (avail > 0) {
    uint8_t chunk = (avail > 32) ? 32 : avail;
    uint8_t bytesRead = Wire1.requestFrom(I2C_GNSS, chunk);
    if (bytesRead == 0) break;
    
    avail -= bytesRead;
    
    while (Wire1.available()) {
      uint8_t b = Wire1.read();
      switch (ubx_state) {
        case 0: if (b == 0xB5) ubx_state = 1; break;
        case 1: if (b == 0x62) ubx_state = 2; else ubx_state = (b == 0xB5) ? 1 : 0; break;
        case 2: ubx_cls = b; ubx_ckA = b; ubx_ckB = b; ubx_state = 3; break;
        case 3: ubx_id = b; ubx_ckA += b; ubx_ckB += ubx_ckA; ubx_state = 4; break;
        case 4: ubx_len = b; ubx_ckA += b; ubx_ckB += ubx_ckA; ubx_state = 5; break;
        case 5:
          ubx_len |= (uint16_t)(b << 8);
          ubx_ckA += b; ubx_ckB += ubx_ckA;
          ubx_idx = 0;
          if (ubx_len > 1024) ubx_state = 9; 
          else ubx_state = (ubx_len > 0) ? 6 : 7;
          break;
        case 6:
          ubx_buf[ubx_idx++] = b;
          ubx_ckA += b; ubx_ckB += ubx_ckA;
          if (ubx_idx >= ubx_len) ubx_state = 7;
          break;
        case 7:
          if (b == ubx_ckA) ubx_state = 8; else ubx_state = 0;
          break;
        case 8:
          if (b == ubx_ckB) processUBX(ubx_cls, ubx_id, ubx_len, ubx_buf);
          ubx_state = 0;
          break;
        case 9:
          ubx_idx++;
          if (ubx_idx >= ubx_len + 2) ubx_state = 0; 
          break;
      }
    }
  }
}

void auditHardware() {
  logDebug(F("AUDIT: FW v1.6.102"));
  Wire.begin();
  #if defined(ARDUINO_ARCH_RENESAS)
  Wire.setWireTimeout(25000, true);
  #endif
  Wire1.begin(); delay(2000);

  if (sht31.begin(0x44)) { has_SHT31 = true; sht31.heater(false); logDebug(F("AUDIT: SHT31 initialized")); }
  if (bmp.begin_I2C(0x77)) { has_BMP388 = true; logDebug(F("AUDIT: BMP388 initialized")); }
  if (getINA260().begin(0x40)) { has_INA260 = true; logDebug(F("AUDIT: INA260 initialized")); }
  #if CFG_ENABLE_OPTICAL
    doDarkCalibration();
  #endif
  Wire1.beginTransmission(I2C_GNSS);
  if (Wire1.endTransmission() == 0) {
    has_GNSS = true;
    uint8_t p[] = {0x01, 0x07, 0x01}; sendUBX(0x06, 0x01, p, 3);
    p[1] = 0x35; sendUBX(0x06, 0x01, p, 3);
    p[0] = 0x0A; p[1] = 0x38; sendUBX(0x06, 0x01, p, 3);
    logDebug(F("AUDIT: GNSS initialized"));
  }
  
  audit_performed = true;
}

void setup() {
  Bridge.begin();
  
  #if defined(ARDUINO_ARCH_RENESAS)
  analogReadResolution(12);
  #endif
  
  #if CFG_ENABLE_TELEMETRY
  pinMode(PIN_ALERT, OUTPUT); digitalWrite(PIN_ALERT, LOW);
  hc12.begin(9600);
  #endif
  
  #if CFG_ENABLE_OPTICAL
  pinMode(PIN_C12880MA_ST, OUTPUT); pinMode(PIN_C12880MA_CLK, OUTPUT);
  #endif
  
  #if CFG_ENABLE_ANEMOMETER
  pinMode(PIN_ANEMOMETER, INPUT);
  #endif
  
  #if CFG_ENABLE_PROXIMITY
  pinMode(PIN_FRONT_TRIG, OUTPUT); pinMode(PIN_REAR_TRIG, OUTPUT);
  pinMode(PIN_FRONT_ECHO, INPUT); pinMode(PIN_REAR_ECHO, INPUT);
  digitalWrite(PIN_FRONT_TRIG, LOW); digitalWrite(PIN_REAR_TRIG, LOW);
  #endif
  
  delay(3000);
}

void loop() {
  Bridge.update();
  if (!audit_performed && millis() > 10000) auditHardware();
  if (audit_performed) {
    
    #if CFG_ENABLE_PROXIMITY
    pollProx();
    #endif

    #if CFG_ENABLE_OPTICAL
    pollOptical();
    #endif

    static uint32_t gnss_lp = 0;
    if (has_GNSS && (millis() - gnss_lp > 100)) {
      pollUBX();
      gnss_lp = millis();
    }

    static uint32_t lp = 0;
    if (millis() - lp > 5000) {
      
      if (has_SHT31) { c_temp = (int32_t)(sht31.readTemperature()*100); c_hum = (int32_t)(sht31.readHumidity()*100); }
      if (has_BMP388) { c_pres = (int32_t)bmp.readPressure(); }
      if (has_INA260) { c_volt = (int32_t)getINA260().readBusVoltage(); c_curr = (int32_t)(getINA260().readCurrent()*100); c_pwr = (int32_t)(getINA260().readPower()*100); }

      #if CFG_ENABLE_TELEMETRY
      bool alert = (c_temp > 4500 || c_temp < 0 || c_hum > 7000 || c_volt < 2000);
      digitalWrite(PIN_ALERT, alert ? HIGH : LOW);
      #endif

      doc.clear();
      doc[F("local_id")] = local_seq++;
      doc[F("leaflink_firmware_vs")] = F(FW_VERSION);
      doc[F("stm32_uptime_ms")] = millis();
      
      #if CFG_ENABLE_OPTICAL
      doc[F("spectrum")] = serialized(cachedSpecStr.c_str());
      doc[F("integ_clks")] = INTEG_CLKS;
      #endif
      
      #if CFG_ENABLE_ANEMOMETER
      float v_anem = (analogRead(PIN_ANEMOMETER) / 4095.0) * 5.0;
      c_wind = (v_anem < 0.054) ? 0 : (int32_t)(((v_anem - 0.054) / 4.946) * 3240);
      doc[F("wind_speed_ms100")] = c_wind;
      doc[F("anemometer_adc")] = raw_anem;
      #endif
      
      #if CFG_ENABLE_PROXIMITY
      doc[F("front_dist_cm")] = last_front_dist;
      doc[F("rear_dist_cm")] = last_rear_dist;
      doc[F("motor_dir")] = String(move_dir);
      #endif

      if (has_GNSS) {
        doc[F("latitude")] = c_lat; doc[F("longitude")] = c_lon; doc[F("altitude")] = c_alt;
        doc[F("hAcc")] = c_hacc; doc[F("vAcc")] = c_vacc; doc[F("numSVs")] = c_siv;
        doc[F("agcCnt0")] = c_agc0; doc[F("jamInd0")] = c_jam0;
        doc[F("agcCnt1")] = c_agc1; doc[F("jamInd1")] = c_jam1;
        
        if (c_svs[0]) { 
          doc[F("svID")] = (const char*)c_svs; 
          doc[F("cno")] = (const char*)c_cno; 
          doc[F("gnssID")] = (const char*)c_gns; 
        }
        if (c_ts[0]) doc[F("timestamp_gnss")] = (const char*)c_ts;
      }
      
      if (has_SHT31) { doc[F("temp_c_c")] = c_temp; doc[F("hum_rh_c")] = c_hum; }
      if (has_BMP388) { doc[F("pressure_pa")] = c_pres; }
      if (has_INA260) { doc[F("ina_v_mv")] = c_volt; doc[F("ina_c_ma100")] = c_curr; doc[F("ina_p_mw100")] = c_pwr; }
      
      serializeJson(doc, jsonBuf);
      Bridge.notify(F("cpp_to_python"), String(jsonBuf));
      lp = millis();
    }
  }
}