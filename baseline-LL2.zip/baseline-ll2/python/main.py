"""
---Development Version

Change your device name.  Read the readme.

Depending on what sensors you are using, don't forget to set the config flags for light, wind, proximity, and telemetry at the top of the CPP code.

#DynamoDB view URL: http://ec2-18-224-219-60.us-east-2.compute.amazonaws.com/scan_simple2.php
#SQL login: http://18.224.219.60/leaflink_adminer2.php?pgsql=localhost&username=postgres&db=leaflink_raw&ns=public

"""

import json, urllib.request, math, time, sqlite3
from datetime import datetime, timezone
from arduino.app_utils import App, Bridge

HOST_VERSION = "1.0.5"
ENABLE_DEBUG_PRINT = True
ENABLE_JSON_PRINT = True
URL = "https://7hcxwqqt37.execute-api.us-east-2.amazonaws.com/leaflink-default/leaflink-lambda-function"
DEVICE = "ckc-ll2-baseline"
DB_FILE = "emmc_buffer.db"
TRANSMIT_INTERVAL_SEC = 5.0

last_transmit_attempt = 0
last_heartbeat = 0

# ---------- OPTICAL CONSTANTS ----------
N_PIXELS = 288
L_MIN = 340.0
L_MAX = 850.0
DELTA_NM = (L_MAX - L_MIN) / (N_PIXELS - 1)
K_E = 0.005

def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS backlog (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT)''')
    conn.commit()
    conn.close()

init_db()

def pixel_to_nm(p):
    return L_MIN + DELTA_NM * float(p)

def v_lambda(nm):
    if nm < 380.0 or nm > 780.0: return 0.0
    x = nm - 555.0
    sigma = 35.0 if nm < 555.0 else 45.0
    return math.exp(-0.5 * x * x / (sigma * sigma))

def compute_optical_metrics(spec, integ_clks=20):
    if not spec or len(spec) != N_PIXELS: return {}
    norm_spec = [float(s) / float(integ_clks) for s in spec]
    mn = min(norm_spec)
    mx = max(norm_spec)
    mean_val = sum(norm_spec) / N_PIXELS
    pk_idx = norm_spec.index(mx)
    pk_nm = pixel_to_nm(pk_idx) # Omitted in your draft
    
    raw_int, photons = 0.0, 0.0
    h, c, NA = 6.626e-34, 2.998e8, 6.022e23
    
    for i in range(N_PIXELS):
        nm = pixel_to_nm(i)
        v = v_lambda(nm)
        if v > 0.0: raw_int += norm_spec[i] * v * DELTA_NM
        if 400.0 <= nm <= 700.0:
            E = norm_spec[i] * K_E * DELTA_NM
            photons += E / ((h * c) / (nm * 1e-9))
            
    par = (photons / NA) * 1e6
    lux = raw_int * 4.7
    
    metrics = {
        "03_counts_min": int(mn * integ_clks), 
        "04_counts_max": int(mx * integ_clks),
        "05_counts_mean": round(mean_val * integ_clks),
        "06_peak_pixel": int(pk_idx), # Omitted in your draft
        "07_peak_nm": round(pk_nm),   # Omitted in your draft
        "21_PAR_umol_m2_s": round(par * 1.5), 
        "22_lux": round(lux)
    }
    for i in range(13):
        target_nm = 400.0 + (i * 25.0)
        best_idx = min(range(N_PIXELS), key=lambda j: abs(pixel_to_nm(j) - target_nm))
        metrics[f"{i+8:02d}_adc_{int(target_nm)}nm"] = int(spec[best_idx])
    return metrics

def compute_env_power_metrics(current_state):
    metrics = {}
    t = current_state.get("temp_c_c", 0) / 100.0 if "temp_c_c" in current_state else None
    h = current_state.get("hum_rh_c", 0) / 100.0 if "hum_rh_c" in current_state else None
    v = current_state.get("ina_v_mv", 0) / 1000.0 if "ina_v_mv" in current_state else None

    if t is not None: metrics["tempC"] = str(round(t, 2))
    if h is not None: metrics["humidity"] = str(round(h, 2))
    if v is not None: metrics["voltage_V"] = str(round(v, 4))
    if "pressure_pa" in current_state: metrics["pressure"] = str(round(current_state["pressure_pa"]/100.0, 2))
    if "ina_c_ma100" in current_state: metrics["current_mA"] = str(round(current_state["ina_c_ma100"]/100.0, 2))
    if "ina_p_mw100" in current_state: metrics["power_mW"] = str(round(current_state["ina_p_mw100"]/100.0, 2))
    if "anemometer_adc" in current_state:
        v_ane = (current_state["anemometer_adc"] / 4095.0) * 5.0
        metrics["windSpeed"] = str(round(((max(0.054, min(v_ane, 5.0)) - 0.054) / 4.946) * 32.4, 2))

    sys = "SAFE"
    if (t is not None and (t > 45 or t < 0)) or (h is not None and h > 70) or (v is not None and v < 2): sys = "UNSAFE"
    if t is not None or h is not None or v is not None: metrics["systemStatus"] = sys
    return metrics

def print_json(action, data, is_backlog=False):
    if action == "dispatch":
        mode = "[BACKLOG]" if is_backlog else "[LIVE]"
        print(f"PYTHON HOST: {mode} Dispatching -> {json.dumps(data)}", flush=True)
    elif action == "response":
        print(f"PYTHON HOST: AWS Response -> {data}", flush=True)

def transmit(payload, is_backlog=False):
    print("", flush=True)
    if ENABLE_JSON_PRINT:
        print_json("dispatch", payload, is_backlog)
        
    try:
        req = urllib.request.Request(URL, data=json.dumps(payload).encode('utf-8'))
        req.add_header('Content-Type', 'application/json')
        with urllib.request.urlopen(req, timeout=5) as r:
            resp = r.read().decode('utf-8')
            if ENABLE_JSON_PRINT:
                print_json("response", resp)
            return r.getcode() == 200
    except Exception as e:
        if ENABLE_DEBUG_PRINT:
            print(f"PYTHON HOST FAULT: {e}", flush=True)
        return False

def on_cpp_payload(p):
    try:
        data = json.loads(p)
        now_iso = datetime.now(timezone.utc).isoformat()
        
        curr_clks = data.get("integ_clks", 20)
        opt_metrics = compute_optical_metrics(data.get("spectrum"), curr_clks) if "spectrum" in data else {}
        env_metrics = compute_env_power_metrics(data)
        
        aws_payload = {}
        
        aws_payload["datetime"] = now_iso
        aws_payload["device"] = DEVICE
        aws_payload["data_mode"] = "LIVE"
        aws_payload["host_vs"] = HOST_VERSION
        
        passthrough_keys = ["local_id", "leaflink_firmware_vs", "stm32_uptime_ms", "front_dist_cm", "rear_dist_cm", "motor_dir"]
        for k in passthrough_keys:
            if k in data: aws_payload[k] = data[k]
            
        if "systemStatus" in env_metrics: aws_payload["systemStatus"] = env_metrics.pop("systemStatus")
        
        gnss_keys = ["timestamp_gnss", "latitude", "longitude", "altitude", "hAcc", "vAcc", "numSVs", "svID", "gnssID", "cno", "agcCnt0", "jamInd0", "agcCnt1", "jamInd1"]
        for k in gnss_keys:
            if k in data: aws_payload[k] = data[k]

        env_keys = ["tempC", "humidity", "pressure", "windSpeed", "voltage_V", "current_mA", "power_mW"]
        for k in env_keys:
            if k in env_metrics: aws_payload[k] = env_metrics[k]
            
        for k in sorted(opt_metrics.keys()):
            aws_payload[k] = opt_metrics[k]
        
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO backlog (payload) VALUES (?)", (json.dumps(aws_payload),))
        conn.commit()
        
        if ENABLE_JSON_PRINT:
            print(f"PYTHON HOST: Queued from Bridge -> local_id {data.get('local_id', 'N/A')}", flush=True)
            
        conn.close()
    except Exception as e:
        if ENABLE_DEBUG_PRINT:
            print(f"INGESTION FAULT: {e}", flush=True)
            
def on_debug_payload(payload):
    if ENABLE_DEBUG_PRINT: print(f"C++ DEBUG: {payload}", flush=True)

Bridge.provide("cpp_to_python", on_cpp_payload)
Bridge.provide("debug", on_debug_payload)

def loop():
    global last_transmit_attempt, last_heartbeat
    
    current_time = time.time()
    if ENABLE_DEBUG_PRINT and current_time - last_heartbeat >= 10.0:
        print("PYTHON HOST [HEARTBEAT]: Event loop active, awaiting Bridge data...", flush=True)
        last_heartbeat = current_time

    if current_time - last_transmit_attempt >= TRANSMIT_INTERVAL_SEC:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        
        while True:
            c.execute("SELECT id, payload FROM backlog ORDER BY id ASC LIMIT 1")
            row = c.fetchone()
            
            if not row:
                break
                
            row_id, payload_str = row
            try:
                payload = json.loads(payload_str)
                is_backlog = (payload.get("data_mode") == "BUFFERED")
                
                if transmit(payload, is_backlog=is_backlog):
                    c.execute("DELETE FROM backlog WHERE id = ?", (row_id,))
                    conn.commit()
                else:
                    if not is_backlog:
                        payload["data_mode"] = "BUFFERED"
                        payload["timestamp_buffered"] = datetime.now(timezone.utc).isoformat()
                        c.execute("UPDATE backlog SET payload = ? WHERE id = ?", (json.dumps(payload), row_id))
                        conn.commit()
                        if ENABLE_JSON_PRINT: print(f"UPDATED QUEUE TO BUFFERED: {payload}", flush=True)
                    break 
            except Exception as e:
                if ENABLE_DEBUG_PRINT: print(f"QUEUE CORRUPTION FAULT: {e}", flush=True)
                c.execute("DELETE FROM backlog WHERE id = ?", (row_id,))
                conn.commit()
        
        conn.close()
        last_transmit_attempt = time.time()
        
    time.sleep(0.05)

if __name__ == "__main__":
    App.run(user_loop=loop)