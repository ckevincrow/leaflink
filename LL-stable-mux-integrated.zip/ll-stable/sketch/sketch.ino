/*
 * LEAFLINK HARDWARE ACQUISITION FIRMWARE
 * Updated for TCA9548A Qwiic Mux use.
 */

#define ENABLE_DEBUG 1

#include <Wire.h>
#include <Arduino_RouterBridge.h>
#include <SparkFun_u-blox_GNSS_v3.h>
#include <Adafruit_SHT31.h>
#include <Adafruit_BMP3XX.h>
#include <Adafruit_INA260.h>

// ---------- HARDWARE MAPPING ----------
const uint8_t PIN_C12880MA_ST    = 7;
const uint8_t PIN_C12880MA_CLK   = 8;
const uint8_t PIN_C12880MA_VIDEO = A2;
const uint8_t PIN_ANEMOMETER     = A0;
const uint8_t PIN_ALERT          = 9;

// ---------- I2C TARGET ADDRESSES ----------
const uint8_t I2C_ADDR_MUX    = 0x70; // TCA9548A default
const uint8_t I2C_ADDR_GNSS   = 0x42;
const uint8_t I2C_ADDR_INA260 = 0x40;
const uint8_t I2C_ADDR_SHT31  = 0x44;
const uint8_t I2C_ADDR_BMP388 = 0x77;

// ---------- MUX CHANNEL MAP ----------
// Set these to match the actual TCA9548A ports used in hardware.
const uint8_t MUX_CH_GNSS   = 0;
const uint8_t MUX_CH_SHT31  = 1;
const uint8_t MUX_CH_BMP388 = 2;
const uint8_t MUX_CH_INA260 = 3;

// ---------- HARDWARE STATE ----------
bool has_MUX = false;
bool has_GNSS = false;
bool has_C12880MA = false;
bool has_SHT31 = false;
bool has_BMP388 = false;
bool has_INA260 = false;
bool has_ANEMOMETER = false;

SFE_UBLOX_GNSS myGNSS;
Adafruit_SHT31 sht31 = Adafruit_SHT31();
Adafruit_BMP3XX bmp;

Adafruit_INA260& getINA260() {
  static Adafruit_INA260 local_ina;
  return local_ina;
}

// ---------- GNSS CACHE ----------
int32_t cachedLat = 0, cachedLon = 0, cachedAlt = 0;
uint32_t cachedHAcc = 0, cachedVAcc = 0;
uint8_t cachedNumSVs = 0;
uint16_t cachedAgc0 = 0, cachedAgc1 = 0;
uint8_t cachedJam0 = 0, cachedJam1 = 0;
uint8_t cachedFixType = 0;
uint32_t cachedITOW = 0;
String cachedSvs = "", cachedCno = "", cachedGns = "";

// ---------- SPECTROMETER CACHE & CONSTANTS ----------
const int N_PIXELS = 288;
const int INTEG_CLKS = 8;
const int DUMMY_CLKS = 16;
const uint8_t T_HIGH_US = 1;
const uint8_t T_LOW_US = 1;

uint16_t spec[N_PIXELS];
uint16_t darkSpec[N_PIXELS] = {0};
uint16_t currentSpec[N_PIXELS];
bool darkCalDone = false;
String cachedSpecStr = "[]";

// ---------- ENVIRONMENTAL CACHE ----------
int32_t cachedTempC_c = 0;
int32_t cachedHumRH_c = 0;
int32_t cachedPressure_Pa = 0;
int32_t cachedVoltage_mV = 0;
int32_t cachedCurrent_mA_100 = 0;
int32_t cachedPower_mW_100 = 0;
uint16_t cachedAnemometerADC = 0;

inline void clkHigh() { digitalWrite(PIN_C12880MA_CLK, HIGH); delayMicroseconds(T_HIGH_US); }
inline void clkLow() { digitalWrite(PIN_C12880MA_CLK, LOW); delayMicroseconds(T_LOW_US); }

void logDebug(String msg) {
#if ENABLE_DEBUG
  Bridge.notify("debug", msg);
  Bridge.update();
  delay(60);
#endif
}

bool muxSelect(uint8_t channel) {
  if (!has_MUX) return false;
  if (channel > 7) return false;
  Wire.beginTransmission(I2C_ADDR_MUX);
  Wire.write(1 << channel);
  return (Wire.endTransmission() == 0);
}

void muxDisableAll() {
  if (!has_MUX) return;
  Wire.beginTransmission(I2C_ADDR_MUX);
  Wire.write(0x00);
  Wire.endTransmission();
}

bool probeI2COnMux(uint8_t channel, uint8_t address) {
  if (!muxSelect(channel)) return false;
  Wire.beginTransmission(address);
  bool ok = (Wire.endTransmission() == 0);
  muxDisableAll();
  return ok;
}

void getSpectrum(uint16_t *data) {
  digitalWrite(PIN_C12880MA_ST, LOW);
  digitalWrite(PIN_C12880MA_CLK, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_C12880MA_ST, HIGH);
  for (int i = 0; i < INTEG_CLKS; i++) { clkHigh(); clkLow(); }
  digitalWrite(PIN_C12880MA_ST, LOW);
  for (int i = 0; i < DUMMY_CLKS; i++) { clkHigh(); clkLow(); }
  for (int i = 0; i < N_PIXELS; i++) {
    clkHigh();
    data[i] = analogRead(PIN_C12880MA_VIDEO);
    clkLow();
  }
}

void doDarkCalibration() {
  logDebug("Executing dark calibration...");
  const int N = 50;
  uint32_t accum[N_PIXELS] = {0};
  for (int n = 0; n < N; n++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) accum[i] += spec[i];
    delay(10);
  }
  for (int i = 0; i < N_PIXELS; i++) darkSpec[i] = accum[i] / N;
  darkCalDone = true;
  logDebug("Dark calibration complete.");
}

void pollC12880MA() {
  uint32_t accum[N_PIXELS] = {0};
  int samples = 40;
  for (int s = 0; s < samples; s++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) {
      int32_t v = spec[i] - (darkCalDone ? darkSpec[i] : 0);
      accum[i] += (v < 0) ? 0 : v;
    }
    delay(5);
  }

  cachedSpecStr = "[";
  for (int i = 0; i < N_PIXELS; i++) {
    currentSpec[i] = accum[i] / samples;
    cachedSpecStr += String(currentSpec[i]);
    if (i < N_PIXELS - 1) cachedSpecStr += ",";
  }
  cachedSpecStr += "]";
}

void evaluateSafetyLimits() {
  bool alert = false;
  if (has_SHT31) {
    if (cachedTempC_c > 4500 || cachedTempC_c < 0 || cachedHumRH_c > 7000) alert = true;
  }
  if (has_INA260) {
    if (cachedVoltage_mV < 2000) alert = true;
  }
  digitalWrite(PIN_ALERT, alert ? HIGH : LOW);
}

void pollENV() {
  if (has_SHT31 && muxSelect(MUX_CH_SHT31)) {
    float t = sht31.readTemperature();
    float h = sht31.readHumidity();
    if (t == t) cachedTempC_c = (int32_t)(t * 100.0f);
    if (h == h) cachedHumRH_c = (int32_t)(h * 100.0f);
    muxDisableAll();
  }

  if (has_BMP388 && muxSelect(MUX_CH_BMP388)) {
    float p = bmp.readPressure();
    if (p == p) cachedPressure_Pa = (int32_t)p;
    muxDisableAll();
  }

  if (has_INA260 && muxSelect(MUX_CH_INA260)) {
    float v = getINA260().readBusVoltage();
    float c = getINA260().readCurrent();
    float p = getINA260().readPower();
    if (v == v) cachedVoltage_mV = (int32_t)v;
    if (c == c) cachedCurrent_mA_100 = (int32_t)(c * 100.0f);
    if (p == p) cachedPower_mW_100 = (int32_t)(p * 100.0f);
    muxDisableAll();
  }

  if (has_ANEMOMETER) cachedAnemometerADC = analogRead(PIN_ANEMOMETER);
  evaluateSafetyLimits();
}

void initGNSS() {
  if (!probeI2COnMux(MUX_CH_GNSS, I2C_ADDR_GNSS)) {
    logDebug("GNSS: Not detected on mux channel " + String(MUX_CH_GNSS));
    return;
  }

  logDebug("GNSS detected at address 0x42 on mux channel " + String(MUX_CH_GNSS));

  bool beginOK = false;
  for (int attempt = 1; attempt <= 5; attempt++) {
    logDebug("GNSS begin attempt " + String(attempt));
    muxSelect(MUX_CH_GNSS);
    delay(300);
    if (myGNSS.begin(Wire, I2C_ADDR_GNSS)) {
      beginOK = true;
      break;
    }
    muxDisableAll();
    delay(400);
  }

  if (!beginOK) {
    muxDisableAll();
    logDebug("myGNSS.begin(Wire) failed");
    return;
  }

  has_GNSS = true;
  logDebug("myGNSS.begin(Wire) succeeded");

  myGNSS.setI2COutput(COM_TYPE_UBX);
  logDebug("setI2COutput(COM_TYPE_UBX) done");
  myGNSS.setAutoPVT(true);
  logDebug("setAutoPVT(true) done");
  myGNSS.setAutoNAVSAT(true);
  logDebug("setAutoNAVSAT(true) done");
  muxDisableAll();
}

void auditHardware() {
  logDebug("Auditing hardware bus with TCA9548A mux...");
  Wire.begin();
  delay(500);
  Wire.setClock(400000);
  delay(500);

  pinMode(PIN_ALERT, OUTPUT);
  digitalWrite(PIN_ALERT, LOW);

  // Detect mux on upstream bus
  Wire.beginTransmission(I2C_ADDR_MUX);
  has_MUX = (Wire.endTransmission() == 0);
  if (!has_MUX) {
    logDebug("TCA9548A mux not detected at 0x70");
    return;
  }
  logDebug("TCA9548A mux detected at 0x70");
  muxDisableAll();

  // GNSS
  initGNSS();

  // Spectrometer (not on mux)
  logDebug("Probing C12880MA on pins ST:7, CLK:8, VIDEO:A2...");
  pinMode(PIN_C12880MA_ST, OUTPUT);
  pinMode(PIN_C12880MA_CLK, OUTPUT);
  digitalWrite(PIN_C12880MA_ST, LOW);
  digitalWrite(PIN_C12880MA_CLK, LOW);
  analogReadResolution(12);
  has_C12880MA = true;
  cachedSpecStr.reserve(3000);
  doDarkCalibration();

  // SHT31
  if (probeI2COnMux(MUX_CH_SHT31, I2C_ADDR_SHT31)) {
    logDebug("SHT31 detected at address 0x44 on mux channel " + String(MUX_CH_SHT31));
    muxSelect(MUX_CH_SHT31);
    if (sht31.begin(I2C_ADDR_SHT31)) {
      has_SHT31 = true;
      sht31.heater(false);
    }
    muxDisableAll();
  } else {
    logDebug("SHT31: Not detected.");
  }

  // BMP388
  if (probeI2COnMux(MUX_CH_BMP388, I2C_ADDR_BMP388)) {
    logDebug("BMP388 detected at address 0x77 on mux channel " + String(MUX_CH_BMP388));
    muxSelect(MUX_CH_BMP388);
    if (bmp.begin_I2C(I2C_ADDR_BMP388, &Wire)) has_BMP388 = true;
    muxDisableAll();
  } else {
    logDebug("BMP388: Not detected.");
  }

  // INA260
  if (probeI2COnMux(MUX_CH_INA260, I2C_ADDR_INA260)) {
    logDebug("INA260 detected at address 0x40 on mux channel " + String(MUX_CH_INA260));
    muxSelect(MUX_CH_INA260);
    if (getINA260().begin(I2C_ADDR_INA260, &Wire)) has_INA260 = true;
    muxDisableAll();
  } else {
    logDebug("INA260: Not detected.");
  }

  logDebug("Probing Anemometer on analog pin A0...");
  pinMode(PIN_ANEMOMETER, INPUT);
  has_ANEMOMETER = true;
  logDebug("Hardware audit completed.");
}

void pollGNSS() {
  static uint32_t lastNavSatDebug = 0;
  if (!has_GNSS) return;
  if (!muxSelect(MUX_CH_GNSS)) return;

  myGNSS.checkUblox();
  myGNSS.checkCallbacks();

  if (myGNSS.getPVT()) {
    cachedFixType = myGNSS.getFixType();
    cachedLat = myGNSS.getLatitude();
    cachedLon = myGNSS.getLongitude();
    cachedAlt = myGNSS.getAltitudeMSL();
    cachedHAcc = myGNSS.getHorizontalAccEst();
    cachedVAcc = myGNSS.getVerticalAccEst();
    cachedITOW = myGNSS.getTimeOfWeek();
    cachedNumSVs = myGNSS.getSIV();
  }

  bool gotNavSat = myGNSS.getNAVSAT();
  if (gotNavSat) {
    uint8_t navsatNum = myGNSS.packetUBXNAVSAT->data.header.numSvs;
    cachedSvs = ""; cachedCno = ""; cachedGns = "";
    uint8_t limit = navsatNum;
    for (uint8_t i = 0; i < limit; i++) {
      if (i > 0) { cachedSvs += ","; cachedCno += ","; cachedGns += ","; }
      cachedSvs += String(myGNSS.packetUBXNAVSAT->data.blocks[i].svId);
      cachedCno += String(myGNSS.packetUBXNAVSAT->data.blocks[i].cno);
      cachedGns += String(myGNSS.packetUBXNAVSAT->data.blocks[i].gnssId);
    }
    if (millis() - lastNavSatDebug > 5000) {
      logDebug("NAVSAT ok, header numSvs = " + String(navsatNum) + ", svIds = " + cachedSvs);
      lastNavSatDebug = millis();
    }
  } else {
    if (millis() - lastNavSatDebug > 5000) {
      logDebug("NAVSAT not updated");
      lastNavSatDebug = millis();
    }
  }

  UBX_MON_RF_data_t rfData;
  if (myGNSS.getRFinformation(&rfData)) {
    cachedAgc0 = rfData.blocks[0].agcCnt;
    cachedJam0 = rfData.blocks[0].jamInd;
    if (rfData.header.nBlocks > 1) {
      cachedAgc1 = rfData.blocks[1].agcCnt;
      cachedJam1 = rfData.blocks[1].jamInd;
    }
  }

  muxDisableAll();
}

void setup() {
  Bridge.begin();
  delay(3000);
  logDebug("Firmware initialization sequence active.");
  auditHardware();
}

void dispatchGNSS() {
  static uint32_t last_send = 0;
  if (millis() - last_send > 2000) {
    String json = "{"; bool first = true;
    if (has_GNSS) {
      json += "\"latitude\":" + String(cachedLat) + ",\"longitude\":" + String(cachedLon);
      json += ",\"altitude\":" + String(cachedAlt) + ",\"hAcc\":" + String(cachedHAcc);
      json += ",\"vAcc\":" + String(cachedVAcc) + ",\"fixType\":" + String(cachedFixType);
      json += ",\"iTOW_ms\":" + String(cachedITOW) + ",\"numSVs\":" + String(cachedNumSVs);
      json += ",\"agcCnt0\":" + String(cachedAgc0) + ",\"jamInd0\":" + String(cachedJam0);
      json += ",\"agcCnt1\":" + String(cachedAgc1) + ",\"jamInd1\":" + String(cachedJam1);
      json += ",\"svID\":\"" + cachedSvs + "\",\"cno\":\"" + cachedCno + "\",\"gnssID\":\"" + cachedGns + "\"";
      first = false;
    }
    if (has_C12880MA) { if (!first) json += ","; json += "\"spectrum\":" + cachedSpecStr; first = false; }
    if (has_SHT31) { if (!first) json += ","; json += "\"temp_c_c\":" + String(cachedTempC_c) + ",\"hum_rh_c\":" + String(cachedHumRH_c); first = false; }
    if (has_BMP388) { if (!first) json += ","; json += "\"pressure_pa\":" + String(cachedPressure_Pa); first = false; }
    if (has_INA260) { if (!first) json += ","; json += "\"ina_v_mv\":" + String(cachedVoltage_mV) + ",\"ina_c_ma100\":" + String(cachedCurrent_mA_100) + ",\"ina_p_mw100\":" + String(cachedPower_mW_100); first = false; }
    if (has_ANEMOMETER) { if (!first) json += ","; json += "\"anemometer_adc\":" + String(cachedAnemometerADC); }
    json += "}";
    Bridge.notify("cpp_to_python", json);
    last_send = millis();
  }
}

void loop() {
  Bridge.update();
  if (has_GNSS) pollGNSS();
  if (has_C12880MA) pollC12880MA();
  pollENV();
  dispatchGNSS();
}
