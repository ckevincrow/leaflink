# LL

Change your device name.

Ensure you have no libraries other than those listed installed.  In particular, the GNSS libraries are large enough to cause trouble, and we are skipping them in order to parse directly.  

Try running the code with 0 sensors attached, with all your sensors attached, and then with combinations of sensors attached.  You should almost immediately start getting entries in AWS, with any combination.  It may take several minutes for the GNSS to start delivering data (or it may start up right away).  We'll handle bad entries on AWS later.

To use the spectrometer, anemometer, proximity sensor, and telemetry, you will need to set flags at the top of the CPP code - just change the 0 to 1.  Note the pin-outs in the code. 

If you are making edits and run into strange difficulties, consider duplicating the project via the dropdown, and then running the copy - this will eliminate various caching issues on the Uno Q.  You probably won't need to do this.

To do a factory reset of the Uno Q, you'll need to jump 2 pins together on the board and re-power it - instructions are available by searching around online.  You probably won't need to do this.

If you run into trouble, try to take a video of the errors on the screen, or copy and paste a bit more than you think is relevant and post it on Teams.  

--DynamoDB view URL: http://ec2-18-224-219-60.us-east-2.compute.amazonaws.com/scan_simple3.php

--SQL login: http://18.224.219.60/leaflink_adminer2.php?pgsql=localhost&username=postgres&db=leaflink_raw&ns=public
Login with the default credentials which are displayed on the page.  Click leaflink-2, Select Data, Search.  You'll probably want to choose device, =, then type your device name.  

### Description

---Libraries:
MsgPack 0.4.2 

Arduino Routerbridge 0.4.0

ArduinoJson 7.4.3

Adafruit_SHT31 

Adafruit_BMP3XX

Adafruit_INA260


---Incorporates:

#GNSS - U-Blox ZED-F9P GPS RTK-SMA

#Light - Hamamatsu C12880MA

#Temperature and Humidity - SHT30

#Anemometer - ? (it can be turned on by a config flag, and a pin will be read)

#Barometric Pressure - BMP388

#Voltage - INA260 

#Ultrasonic Distance - RWCL-1601

#Telemetry Radio - HC12

