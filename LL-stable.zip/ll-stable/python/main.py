"""
---Development Version: GNSS, Light, Environmental, Power with debug code

#DynamoDB view URL: http://ec2-18-224-219-60.us-east-2.compute.amazonaws.com/scan_simple2.php

#SQL login: http://18.224.219.60/leaflink_adminer2.php?pgsql=localhost&username=postgres&db=leaflink_raw&ns=public

Description

---Libraries:

RTClib 2.1.4

SparkFun u-blox GNSS v3 3.1.13

MsgPack 0.4.2

SdFat 2.3.0

Adafruit_SHT31

Adafruit_BMP3XX

Adafruit_INA260

---Incorporates:

#GNSS - U-Blox ZED-F9P GPS RTK-SMA

#Light - Hamamatsu C12880MA

#Temperature and Humidity - SHT30

#Anemometer

#Barometric Pressure

#Voltage - INA260

---TBD:

#Ultrasonic Distance - RWCL-1601

#Telemetry Radio V3 SKU17022, 17023

#RTC - DS3231

#Logging SD - has cs, sck, mosi, miso, vcc, gnd; 1117-3,3 xblw 2435A and sn74hc125 47at348a
"""

import json, urllib.request, math
from time import sleep
from datetime import datetime, timezone
from arduino.app_utils import App, Bridge

ENABLE_DEBUG_PRINT = True #
ENABLE_JSON_PRINT = True #JSON submitted to AWS, and AWS response

url = "https://7hcxwqqt37.execute-api.us-east-2.amazonaws.com/leaflink-default/leaflink-lambda-function"
device = "ckc-unoq"
state = {}
idle_cycles = 0

# ---------- OPTICAL CONSTANTS ----------
# Defines the physical characteristics of the Hamamatsu C12880MA grating.
N_PIXELS = 288
L_MIN = 340.0
L_MAX = 850.0
DELTA_NM = (L_MAX - L_MIN) / (N_PIXELS - 1)
K_E = 1.0e-6

# Translates a hardware pixel index (0-287) to its corresponding optical wavelength.
def pixel_to_nm(p):
    return L_MIN + DELTA_NM * float(p)

# CIE photopic luminosity function (human eye response). Used to calculate Lux.
def v_lambda(nm):
    if nm < 380.0 or nm > 780.0: return 0.0
    x = nm - 555.0
    sigma = 35.0 if nm < 555.0 else 45.0
    return math.exp(-0.5 * x * x / (sigma * sigma))

# Computes PAR (400-700nm photon count) and Lux. Extracts 25nm bands for schema.
def compute_optical_metrics(spec):
    if not spec or len(spec) != N_PIXELS: return {}
    mn, mx = min(spec), max(spec)
    pk_idx = spec.index(mx)
    raw_int, photons = 0.0, 0.0
    h, c, NA = 6.626e-34, 2.998e8, 6.022e23
    
    for i in range(N_PIXELS):
        nm = pixel_to_nm(i)
        v = v_lambda(nm)
        if v > 0.0: raw_int += spec[i] * v * DELTA_NM
        if 400.0 <= nm <= 700.0:
            E = spec[i] * K_E * DELTA_NM
            photons += E / ((h * c) / (nm * 1e-9))
            
    lux = (raw_int - 97.1) if (raw_int - 97.1) > 0 else 0.0
    lux_scalar = 0.001720 if lux < 100000 else (0.0018 if lux < 200000 else 0.0096)
    
    metrics = {
        "03_counts_min": int(mn), "04_counts_max": int(mx), "05_counts_mean": round(sum(spec)/N_PIXELS),
        "06_peak_pixel": int(pk_idx), "07_peak_nm": round(pixel_to_nm(pk_idx)),
        "21_PAR_umol_m2_s": round((photons / NA) * 1e12), "22_lux": round(lux * lux_scalar * 1000.0)
    }
    for i in range(13):
        target_nm = 400.0 + (i * 25.0)
        best_idx = min(range(N_PIXELS), key=lambda j: abs(pixel_to_nm(j) - target_nm))
        metrics[f"{i+8:02d}_adc_{int(target_nm)}nm"] = int(spec[best_idx])
    return metrics

# Reconstructs scaled environmental readings. Translates ADC to wind speed (m/s).
def compute_env_power_metrics(current_state):
    metrics = {}
    t = current_state.get("temp_c_c", 0) / 100.0 if "temp_c_c" in current_state else None
    h = current_state.get("hum_rh_c", 0) / 100.0 if "hum_rh_c" in current_state else None
    v = current_state.get("ina_v_mv", 0) / 1000.0 if "ina_v_mv" in current_state else None

    if t is not None: metrics["tempC"] = str(round(t, 2))
    if h is not None: metrics["humidity"] = str(round(h, 2))
    if v is not None: metrics["voltage_V"] = str(round(v, 4))
    if "pressure_pa" in current_state: metrics["pressure"] = str(round(current_state["pressure_pa"]/100.0, 2))
    if "ina_c_ma100" in current_state: metrics["current_mA"] = str(round(current_state["ina_c_ma100"]/100.0, 2))
    if "ina_p_mw100" in current_state: metrics["power_mW"] = str(round(current_state["ina_p_mw100"]/100.0, 2))
    if "anemometer_adc" in current_state:
        v_ane = (current_state["anemometer_adc"] / 4095.0) * 5.0
        metrics["windSpeed"] = str(round(((max(0.054, min(v_ane, 5.0)) - 0.054) / 4.946) * 32.4, 2))

    sys = "SAFE"
    if (t is not None and (t > 45 or t < 0)) or (h is not None and h > 70) or (v is not None and v < 2): sys = "UNSAFE"
    if t is not None or h is not None or v is not None: metrics["systemStatus"] = sys
    return metrics

def on_cpp_payload(payload):
    try: state.update(json.loads(payload))
    except: pass

def on_debug_payload(payload):
    if ENABLE_DEBUG_PRINT: print(f"C++ DEBUG: {payload}", flush=True)

Bridge.provide("cpp_to_python", on_cpp_payload)
Bridge.provide("debug", on_debug_payload)

def loop():
    global idle_cycles
    if not state:
        idle_cycles += 1
        if idle_cycles % 100 == 0 and ENABLE_DEBUG_PRINT: print("PYTHON HOST: Awaiting C++ payload...", flush=True)
        sleep(0.1); return
    
    idle_cycles = 0
    timestamp = datetime.now(timezone.utc).isoformat()
    aws_payload = {"datetime": timestamp, "device": device, "hostMs": str(int(datetime.now().timestamp() * 1000))}
    
    if "latitude" in state:
        for k in ["latitude", "longitude", "altitude", "hAcc", "vAcc", "numSVs", "agcCnt0", "jamInd0", "agcCnt1", "jamInd1", "svID", "cno", "gnssID"]:
            if k in state: aws_payload[k] = state[k]

    if "spectrum" in state: aws_payload.update(compute_optical_metrics(state.get("spectrum")))
    aws_payload.update(compute_env_power_metrics(state))

    if ENABLE_JSON_PRINT: print(f"PYTHON HOST: Dispatching JSON -> {json.dumps(aws_payload)}", flush=True)
    try:
        req = urllib.request.Request(url, data=json.dumps(aws_payload).encode('utf-8'))
        req.add_header('Content-Type', 'application/json')
        with urllib.request.urlopen(req, timeout=5) as r: 
            if ENABLE_JSON_PRINT: print(f"PYTHON HOST: AWS Response -> {r.read().decode('utf-8')}", flush=True)
    except Exception as e:
        if ENABLE_DEBUG_PRINT: print(f"PYTHON HOST FAULT: {e}", flush=True)
    sleep(2)

if __name__ == "__main__":
    App.run(user_loop=loop)