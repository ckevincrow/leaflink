/*
 * LEAFLINK HARDWARE ACQUISITION FIRMWARE
 */

// Print debug messages:
#define ENABLE_DEBUG 1 

#include <Wire.h>
#include <Arduino_RouterBridge.h>
#include <SparkFun_u-blox_GNSS_v3.h>
#include <Adafruit_SHT31.h>
#include <Adafruit_BMP3XX.h>
#include <Adafruit_INA260.h>

// ---------- HARDWARE MAPPING ----------
// Centralizes physical pin designations to facilitate rapid schematic revisions.
const uint8_t PIN_C12880MA_ST    = 7; 
const uint8_t PIN_C12880MA_CLK   = 8;
const uint8_t PIN_C12880MA_VIDEO = A2;
const uint8_t PIN_ANEMOMETER     = A0;
const uint8_t PIN_ALERT          = 9;

// Defines static I2C bus addresses for polling targets.
const uint8_t I2C_ADDR_GNSS   = 0x42;
const uint8_t I2C_ADDR_INA260 = 0x40;
const uint8_t I2C_ADDR_SHT31  = 0x44;
const uint8_t I2C_ADDR_BMP388 = 0x77;

// ---------- HARDWARE STATE ----------
// Boolean matrix tracking successful initialization. Prevents the main loop 
// from querying absent hardware, which would induce fatal bus wait states.
bool has_GNSS = false;
bool has_C12880MA = false;
bool has_SHT31 = false;
bool has_BMP388 = false;
bool has_INA260 = false;
bool has_ANEMOMETER = false;

SFE_UBLOX_GNSS myGNSS;
Adafruit_SHT31 sht31 = Adafruit_SHT31();
Adafruit_BMP3XX bmp;

// Static Singleton: Provides local static instance to prevent pre-boot memory corruption.
// The Adafruit INA260 module necessitates delayed instantiation. 
// Unlike GNSS or SHT31, its constructor allocates complex I2C register sub-objects. 
// Doing this globally triggers a fatal memory violation before the Zephyr RTOS 
// initializes clocks. getINA260() defers this until setup().

Adafruit_INA260& getINA260() {
  static Adafruit_INA260 local_ina;
  return local_ina;
}

// ---------- GNSS CACHE ----------
// Stores the most recent spatial and signal integrity coordinates.
int32_t cachedLat = 0, cachedLon = 0, cachedAlt = 0;
uint32_t cachedHAcc = 0, cachedVAcc = 0;
uint8_t cachedNumSVs = 0;
uint16_t cachedAgc0 = 0, cachedAgc1 = 0;
uint8_t cachedJam0 = 0, cachedJam1 = 0;
String cachedSvs = "", cachedCno = "", cachedGns = "";

// ---------- SPECTROMETER CACHE & CONSTANTS ----------
// Configures the timing requirements for the Hamamatsu C12880MA linear sensor.
const int N_PIXELS = 288;
const int INTEG_CLKS = 8;
const int DUMMY_CLKS = 16;
const uint8_t T_HIGH_US = 1;
const uint8_t T_LOW_US = 1;

uint16_t spec[N_PIXELS];             
uint16_t darkSpec[N_PIXELS] = {0};   
uint16_t currentSpec[N_PIXELS];      
bool darkCalDone = false;
String cachedSpecStr = "[]";         

// ---------- ENVIRONMENTAL CACHE ----------
// Stores scalar environmental variables. Values are multiplied by 100 and 
// cast to integers to prevent the Zephyr compiler from attempting to link the missing 
// standard math library (libm) during floating-point string conversions.
int32_t cachedTempC_c = 0;         
int32_t cachedHumRH_c = 0;         
int32_t cachedPressure_Pa = 0;     
int32_t cachedVoltage_mV = 0;      
int32_t cachedCurrent_mA_100 = 0;  
int32_t cachedPower_mW_100 = 0;    
uint16_t cachedAnemometerADC = 0;  

// ---------- HARDWARE CONTROL FUNCTIONS ----------
// Manages the precise microsecond timing required to clock the optical sensor.
inline void clkHigh() { digitalWrite(PIN_C12880MA_CLK, HIGH); delayMicroseconds(T_HIGH_US); }
inline void clkLow() { digitalWrite(PIN_C12880MA_CLK, LOW); delayMicroseconds(T_LOW_US); }

// Diagnostic Logging: Routes strings to the Python debug listener with temporal buffering.
void logDebug(String msg) {
  #if ENABLE_DEBUG
  Bridge.notify("debug", msg);
  Bridge.update();
  delay(150); 
  #endif
}

// Executes a single integration cycle of the Hamamatsu C12880MA.
void getSpectrum(uint16_t *data) {
  digitalWrite(PIN_C12880MA_ST, LOW);
  digitalWrite(PIN_C12880MA_CLK, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_C12880MA_ST, HIGH);
  for (int i = 0; i < INTEG_CLKS; i++) { clkHigh(); clkLow(); }
  digitalWrite(PIN_C12880MA_ST, LOW);
  for (int i = 0; i < DUMMY_CLKS; i++) { clkHigh(); clkLow(); }
  for (int i = 0; i < N_PIXELS; i++) {
    clkHigh();
    data[i] = analogRead(PIN_C12880MA_VIDEO);
    clkLow();
  }
}

// Captures 50 samples immediately upon boot to establish a zero-light noise floor.
void doDarkCalibration() {
  logDebug("Executing dark calibration...");
  const int N = 50;
  uint32_t accum[N_PIXELS] = {0};
  for (int n = 0; n < N; n++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) accum[i] += spec[i];
    delay(10);
  }
  for (int i = 0; i < N_PIXELS; i++) darkSpec[i] = accum[i] / N;
  darkCalDone = true;
  logDebug("Dark calibration complete.");
}

// Acquires 40 sequential optical samples, subtracts the thermal noise floor, 
// averages the result to mitigate statistical shot noise, and formats the JSON string.
void pollC12880MA() {
  uint32_t accum[N_PIXELS] = {0};
  int samples = 40;
  for (int s = 0; s < samples; s++) {
    getSpectrum(spec);
    for (int i = 0; i < N_PIXELS; i++) {
      int32_t v = spec[i] - (darkCalDone ? darkSpec[i] : 0);
      accum[i] += (v < 0) ? 0 : v;
    }
    delay(5);
  }

  cachedSpecStr = "[";
  for (int i = 0; i < N_PIXELS; i++) {
    currentSpec[i] = accum[i] / samples;
    cachedSpecStr += String(currentSpec[i]);
    if (i < N_PIXELS - 1) cachedSpecStr += ",";
  }
  cachedSpecStr += "]";
}

// Triggers a physical alert pin if environmental or power metrics exceed bounds.
void evaluateSafetyLimits() {
  bool alert = false;
  if (has_SHT31) {
    if (cachedTempC_c > 4500 || cachedTempC_c < 0 || cachedHumRH_c > 7000) alert = true;
  }
  if (has_INA260) {
    if (cachedVoltage_mV < 2000) alert = true;
  }
  digitalWrite(PIN_ALERT, alert ? HIGH : LOW);
}

// Queries environmental sensors. Validates float returns via self-equivalence 
// (NaN check) before casting to integers for transmission.
void pollENV() {
  if (has_SHT31) {
    float t = sht31.readTemperature();
    float h = sht31.readHumidity();
    if (t == t) cachedTempC_c = (int32_t)(t * 100.0f); 
    if (h == h) cachedHumRH_c = (int32_t)(h * 100.0f);
  }
  if (has_BMP388) {
    float p = bmp.readPressure();
    if (p == p) cachedPressure_Pa = (int32_t)p;
  }
  if (has_INA260) {
    float v = getINA260().readBusVoltage();
    float c = getINA260().readCurrent();
    float p = getINA260().readPower();
    if (v == v) cachedVoltage_mV = (int32_t)v; 
    if (c == c) cachedCurrent_mA_100 = (int32_t)(c * 100.0f);
    if (p == p) cachedPower_mW_100 = (int32_t)(p * 100.0f);
  }
  if (has_ANEMOMETER) cachedAnemometerADC = analogRead(PIN_ANEMOMETER);
  evaluateSafetyLimits();
}


// Verifies physical I2C connectivity by pinging the address for an ACK bit. 
// Prevents the system from hanging on unconnected buses.
bool probeI2C(uint8_t address, TwoWire &wirePort) {
  wirePort.beginTransmission(address);
  return (wirePort.endTransmission() == 0);
}

// Executes the hardware capability matrix. Initializes modules only if 
// physical presence is verified via probeI2C.
void auditHardware() {
  logDebug("Auditing hardware bus...");
  Wire.begin(); Wire1.begin(); Wire1.setClock(400000);
  pinMode(PIN_ALERT, OUTPUT); digitalWrite(PIN_ALERT, LOW);

  if (probeI2C(I2C_ADDR_GNSS, Wire1)) { 
    logDebug("GNSS detected at address 0x42.");
    if (myGNSS.begin(Wire1)) {
      has_GNSS = true;
      myGNSS.setI2COutput(COM_TYPE_UBX);
      myGNSS.newCfgValset(); 
      myGNSS.addCfgValset8(UBLOX_CFG_SIGNAL_GLO_ENA, 0); 
      myGNSS.addCfgValset8(UBLOX_CFG_SIGNAL_BDS_ENA, 0); 
      myGNSS.sendCfgValset();
      myGNSS.setAutoPVT(true);
      myGNSS.setAutoNAVSAT(true);
    }
  } else { logDebug("GNSS: Not detected."); }

  logDebug("Probing C12880MA on pins ST:7, CLK:8, VIDEO:A2...");
  pinMode(PIN_C12880MA_ST, OUTPUT); pinMode(PIN_C12880MA_CLK, OUTPUT);
  digitalWrite(PIN_C12880MA_ST, LOW); digitalWrite(PIN_C12880MA_CLK, LOW);
  analogReadResolution(12);
  has_C12880MA = true; 
  cachedSpecStr.reserve(3000);
  doDarkCalibration();

  if (probeI2C(I2C_ADDR_SHT31, Wire)) {
    logDebug("SHT31 detected at address 0x44.");
    if (sht31.begin(I2C_ADDR_SHT31)) {
        has_SHT31 = true;
        sht31.heater(false);
    }
  } else { logDebug("SHT31: Not detected."); }
  
  if (probeI2C(I2C_ADDR_BMP388, Wire)) {
    logDebug("BMP388 detected at address 0x77.");
    if (bmp.begin_I2C(I2C_ADDR_BMP388, &Wire)) has_BMP388 = true;
  } else { logDebug("BMP388: Not detected."); }

  if (probeI2C(I2C_ADDR_INA260, Wire)) {
    logDebug("INA260 detected at address 0x40.");
    if (getINA260().begin(I2C_ADDR_INA260, &Wire)) has_INA260 = true;
  } else { logDebug("INA260: Not detected."); }

  logDebug("Probing Anemometer on analog pin A0...");
  pinMode(PIN_ANEMOMETER, INPUT); has_ANEMOMETER = true;
  logDebug("Hardware audit completed.");
}

// Retrieves the latest payload from the u-blox module. Extracts coordinates, 
// accuracy metrics, satellite vectors, and radio interference parameters.
void pollGNSS() {
  myGNSS.checkUblox(); 
  if (myGNSS.getPVT()) {
    cachedLat = myGNSS.getLatitude(); cachedLon = myGNSS.getLongitude();
    cachedAlt = myGNSS.getAltitudeMSL(); cachedHAcc = myGNSS.getHorizontalAccEst();
    cachedVAcc = myGNSS.getVerticalAccEst();
  }
  if (myGNSS.getNAVSAT()) {
    cachedNumSVs = myGNSS.packetUBXNAVSAT->data.header.numSvs;
    cachedSvs = ""; cachedCno = ""; cachedGns = "";
    uint8_t limit = (cachedNumSVs > 6) ? 6 : cachedNumSVs; 
    for (uint8_t i = 0; i < limit; i++) {
      if (i > 0) { cachedSvs += ","; cachedCno += ","; cachedGns += ","; }
      cachedSvs += String(myGNSS.packetUBXNAVSAT->data.blocks[i].svId);
      cachedCno += String(myGNSS.packetUBXNAVSAT->data.blocks[i].cno);
      cachedGns += String(myGNSS.packetUBXNAVSAT->data.blocks[i].gnssId);
    }
  }
  UBX_MON_RF_data_t rfData;
  if (myGNSS.getRFinformation(&rfData)) {
    cachedAgc0 = rfData.blocks[0].agcCnt; cachedJam0 = rfData.blocks[0].jamInd;
    if (rfData.header.nBlocks > 1) {
      cachedAgc1 = rfData.blocks[1].agcCnt; cachedJam1 = rfData.blocks[1].jamInd;
    }
  }
}

// System initialization point. Binds the cross-processor bridge.
// I2C AUDIT: Hardware probing occurs on boot. If a sensor is detected, the 
// specific I2C address is reported. If absent, "Not detected" is printed.
void setup() { Bridge.begin(); delay(3000); logDebug("Firmware initialization sequence active."); auditHardware(); }

// Compiles the cached hardware data into a singular JSON structure every 2 seconds.
// Dispatches the payload to the Python host using the designated bridge key.
void dispatchGNSS() {
  static uint32_t last_send = 0;
  if (millis() - last_send > 2000) { 
    String json = "{"; bool first = true;
    if (has_GNSS) {
      json += "\"latitude\":" + String(cachedLat) + ",\"longitude\":" + String(cachedLon);
      json += ",\"altitude\":" + String(cachedAlt) + ",\"hAcc\":" + String(cachedHAcc);
      json += ",\"vAcc\":" + String(cachedVAcc) + ",\"numSVs\":" + String(cachedNumSVs);
      json += ",\"agcCnt0\":" + String(cachedAgc0) + ",\"jamInd0\":" + String(cachedJam0);
      json += ",\"agcCnt1\":" + String(cachedAgc1) + ",\"jamInd1\":" + String(cachedJam1);
      json += ",\"svID\":\"" + cachedSvs + "\",\"cno\":\"" + cachedCno + "\",\"gnssID\":\"" + cachedGns + "\"";
      first = false;
    }
    if (has_C12880MA) { if (!first) json += ","; json += "\"spectrum\":" + cachedSpecStr; first = false; }
    if (has_SHT31) { if (!first) json += ","; json += "\"temp_c_c\":" + String(cachedTempC_c) + ",\"hum_rh_c\":" + String(cachedHumRH_c); first = false; }
    if (has_BMP388) { if (!first) json += ","; json += "\"pressure_pa\":" + String(cachedPressure_Pa); first = false; }
    if (has_INA260) { if (!first) json += ","; json += "\"ina_v_mv\":" + String(cachedVoltage_mV) + ",\"ina_c_ma100\":" + String(cachedCurrent_mA_100) + ",\"ina_p_mw100\":" + String(cachedPower_mW_100); first = false; }
    if (has_ANEMOMETER) { if (!first) json += ","; json += "\"anemometer_adc\":" + String(cachedAnemometerADC); }
    json += "}";
    Bridge.notify("cpp_to_python", json);
    last_send = millis();
  }
}

// Continuous execution cycle. Polls available hardware sequentially.
void loop() { Bridge.update(); if (has_GNSS) pollGNSS(); if (has_C12880MA) pollC12880MA(); pollENV(); dispatchGNSS(); }