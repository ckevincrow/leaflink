# 😀 LL
LeafLink is an Arduino Uno Q project I am developing in conjunction with a professor and 5 team members.  One Arduino Uno Q will be in a cart on tracks in a forest, another will be in an open sky position, both running headlessly.  By measuring GNSS signal attentuation of the device under the forest as compared to the device in the open sky position, the moisture content of the forest will be derived.  A number of sensors will gather useful data, which is passed from CPP to JSON, and uploaded to AWS DynamoDB - all data analysis will take place on AWS.  I want to use the same Uno Q code base for both Arduino Uno Q microprocessors.  My teammates and professor have developed code pertaining to individual sensors, which I am in the process of integrating to the code base.  I need your help to integrate a few more sensors.  We need to proceed very carefully, item by item, and within each item step by step, ensuring stability of the code base, and high-quality documentation.  I am working in Arduino App Lab.  In my next two submissions to you, I will provide the code base - wait for both the CPP and Python.  After reviewing both, please ask me clarificatory questions to ensure you do not hallucinate or otherwise adjust the code unnecessarily.   The code must allow for any combination of sensors to be present, or none at all - each of my teammates' has only 1-3 sensors.  Once I am finished, I will send this code to them for testing against the sensors they have.  We are working remotely from one another, so troubleshooting is difficult - I want to do everything in my power to provide robust, easily-comprehended, easily-debugged, configurable code.    

---Development Version: GNSS, Light, Environmental, Power
with debug code

#DynamoDB view URL: http://ec2-18-224-219-60.us-east-2.compute.amazonaws.com/scan_simple2.php

#SQL login: http://18.224.219.60/leaflink_adminer2.php?pgsql=localhost&username=postgres&db=leaflink_raw&ns=public


### Description

---Libraries:

RTClib 2.1.4 

SparkFun u-blox GNSS v3 3.1.13 

MsgPack 0.4.2 

SdFat 2.3.0

Adafruit_SHT31 

Adafruit_BMP3XX

Adafruit_INA260





---Incorporates:

#GNSS - U-Blox ZED-F9P GPS RTK-SMA

#Light - Hamamatsu C12880MA

#Temperature and Humidity - SHT30

#Anemometer

#Barometric Pressure

#Voltage - INA260 


---TBD:

#Ultrasonic Distance - RWCL-1601

#Telemetry Radio V3 SKU17022, 17023

#RTC - DS3231

#Logging SD - has cs, sck, mosi, miso, vcc, gnd; 1117-3,3 xblw 2435A and sn74hc125 47at348a

wifi for headless deployment

